public class PejalanKaki {
    String nama;

    public void menyeberang() {
        System.out.println("Pejalan kaki akan melewati zebra cross");
    }

    public void bersiap() {
        System.out.println("Pejalan kaki bersiap melewati zebra cross");
    }

    public void menunggu() {
        System.out.println("Pejalan kaki menunggu untuk menyeberang");
    }
}
