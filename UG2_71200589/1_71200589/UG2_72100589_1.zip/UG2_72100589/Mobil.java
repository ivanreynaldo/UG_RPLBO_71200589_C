public class Mobil {
    String jenis;
    String mesin;

    public void jalan() {
        System.out.println("Mobil goes brrrr");
    }

    public void kurangiKecepatan() {
        System.out.println("Mobil slow down...");
    }

    public void berhenti() {
        System.out.println("Mobil stop!");
    }
}
