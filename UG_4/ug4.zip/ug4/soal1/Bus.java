package com.ug4.soal1;

import java.util.ArrayList;

public class Bus {
    String name;
    Driver driver;
    int CAPACITY;
    final ArrayList<Passenger> passennger;
    int usedCapacity;
    final double fares;
    double profit;
    String[] Route;

    public Bus(String name, Driver driver) {
        this.name = name;
        this.driver = driver;
    }

    public String getName(){
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public com.ug4.soal1.Driver getDriver() {
        return driver;
    }

    public void setDriver(com.ug4.soal1.Driver driver) {
        this.driver = driver;
    }

    public int getCAPACITY() {
        return CAPACITY;
    }

    public ArrayList<Passenger> getPassennger() {
        return passennger;
    }

    public int getUsedCapacity() {
        return usedCapacity;
    }

    private void setUsedCapacity(int usedCapacity) {
        this.usedCapacity = usedCapacity;
    }

    public double getFares() {
        return fares;
    }

    public double getProfit() {
        return profit;
    }

    public String[] getRoute() {
        return Route;
    }

    public void setProfit(double profit) {
        this.profit = profit;
    }

    public Boolean checkPassengerBalance(Passenger check){
        return true;
    }

    public void topUpBalance(double Passenger){

    }

    private void takePassenger (Passenger take){

    }

    public void dropPassengers(String rute, Passenger psg){

    }

    public void proceesOrder(String passenger){

    }

    public String cancelOrder(){

        return null;
    }


}
